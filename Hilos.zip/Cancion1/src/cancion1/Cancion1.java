
package cancion1;


public class Cancion1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        audio repro = new audio();
        repro.setVisible(true);
        
    }
    
}
